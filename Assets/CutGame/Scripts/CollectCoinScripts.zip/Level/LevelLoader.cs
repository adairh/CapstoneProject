﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelLoader : MonoBehaviour
{
    public static int currentLevelIndex;
    public static LevelData.Level levelToLoad;

    public static bool loadLevelGrid;
    public LevelData levelData;

    public void LoadLevel(int index)
    {
        currentLevelIndex = index;
        levelToLoad = levelData.levels[index];

        SceneManager.LoadScene(3, LoadSceneMode.Single);
    }

    public void ReloadLevel()
    {
        SceneManager.LoadScene(3, LoadSceneMode.Single);
    }

    public void LoadNextLevel()
    {
        if (IsNextLevelAvailable()) LoadLevel(currentLevelIndex + 1);
    }

    public bool IsNextLevelAvailable()
    {
        var nextLevelIndex = currentLevelIndex + 1;

        if (levelData.levels.Count > nextLevelIndex &&
            levelData.levels[nextLevelIndex].unlocked)
            return true;
        return false;
    }

    public void LoadMenu(bool levelGrid)
    {
        if (levelGrid)
            loadLevelGrid = true;
        else
            loadLevelGrid = false;

        SceneManager.LoadScene(2, LoadSceneMode.Single);
    }
}