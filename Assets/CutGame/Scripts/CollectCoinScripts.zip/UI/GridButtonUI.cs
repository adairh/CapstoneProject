﻿using UnityEngine;
using UnityEngine.UI;

public class GridButtonUI : MonoBehaviour
{
    public Button button;
    public Text label;

    [Space] public Image locked;

    [Space] public Image[] stars;

    [Space] public Color starColor;

    [Space] public Image hard;

    private int index;
    private LevelLoader levelLoader;

    public void EnterLevel()
    {
        AudioManager.Play(SFX.Click);

        Fade.instance.FadeOut(() => levelLoader.LoadLevel(index));
    }

    // Sets up buttons instanciated in level grid
    public void SetUpButton(LevelLoader levelLoader, int index, LevelData.Level level)
    {
        if (level.unlocked)
        {
            this.levelLoader = levelLoader;
            this.index = index;
            label.text = (index + 1).ToString();

            for (var i = 0; i < level.rating; i++) stars[i].color = starColor;
        }
        else
        {
            button.interactable = false;

            label.gameObject.SetActive(false);
            locked.gameObject.SetActive(true);

            stars[0].transform.parent.gameObject.SetActive(false);
        }

        if (level.hardmode) hard.gameObject.SetActive(true);
    }
}