﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace Manipulator
{
    public class CreateShapeBatchAction : IUndoableAction
    {
        private readonly List<ShapeData> shapeDataList;
        private readonly List<Shape> createdShapes = new();

        public Action<Shape> OnShapeSpawned; // 👈 ADD THIS LINE

        public CreateShapeBatchAction(List<ShapeData> shapeDataList)
        {
            this.shapeDataList = shapeDataList;
        }

        public void Redo()
        {
            foreach (var data in shapeDataList)
            {
                Shape shape = ShapeFactory.CreateFromData(data);
                createdShapes.Add(shape);
                OnShapeSpawned?.Invoke(shape); // 👈 INVOKE IF ASSIGNED
            }
        }

        public void Undo()
        {
            foreach (var shape in createdShapes)
                shape.DestroyShape();
        }
    }
}