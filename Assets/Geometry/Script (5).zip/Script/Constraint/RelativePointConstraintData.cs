﻿using System;

namespace Manipulator
{
    public enum RelativeTargetType { Segment, Plane }

    [Serializable]
    public class RelativePointConstraintData : ConstraintData
    {
        public string PointId;
        public string TargetShapeId;
        public RelativeTargetType TargetType;
        public float T;     // nếu là segment
        public float U, V;  // nếu là plane

        public override void Restore()
        {
            var point = ShapeStorage.GetById(PointId) as Point;
            var shape = ShapeStorage.GetById(TargetShapeId);
            if (point == null || shape == null) return;

            var constraint = point.gameObject.AddComponent<RelativePointConstraint>();
            constraint.Owner = point;
            constraint.SetTarget(shape, TargetType, T, U, V);
        }
    }

}