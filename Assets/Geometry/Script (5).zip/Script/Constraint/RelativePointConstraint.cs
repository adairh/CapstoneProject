﻿using System.Collections.Generic;
using UnityEngine;

namespace Manipulator
{
    public class RelativePointConstraint : Constraint
    {
        public Point Owner;
        private Shape target;
        private RelativeTargetType type;
        private float t, u, v;

        public void SetTarget(Shape shape, RelativeTargetType type, float t, float u, float v)
        {
            this.target = shape;
            this.type = type;
            this.t = t; this.u = u; this.v = v;
            shape.OnChanged += OnTargetChanged;
            UpdatePosition(); // áp dụng ngay lúc bind
        }

        private void OnTargetChanged(Shape shape) => UpdatePosition();

        private void UpdatePosition()
        {
            if (target == null || Owner == null) return;

            if (type == RelativeTargetType.Segment && target is Segment seg)
            {
                Vector3 a = seg.StartPoint.transform.position;
                Vector3 b = seg.EndPoint.transform.position;
                Vector3 pos = Vector3.Lerp(a, b, t);
                Owner.MoveTo(pos, silent: true);
            }
            else if (type == RelativeTargetType.Plane && target is PlaneShape plane)
            {
                var pts = plane.PivotPoints;
                if (pts.Count < 3) return;

                Vector3 a = pts[0].transform.position;
                Vector3 b = pts[1].transform.position;
                Vector3 c = pts[2].transform.position;
                Vector3 pos = a + u * (b - a) + v * (c - a);
                Owner.MoveTo(pos, silent: true);
            }
        }

        public override void ApplyConstraint(Shape changedShape, Vector3 delta) => UpdatePosition();

        public override IEnumerable<Shape> GetRelatedShapes() => new[] { target };

        public override bool HasShape(Shape shape)
        {
            return false;
        }

        public override ConstraintData Serialize() => new RelativePointConstraintData
        {
            ConstraintId = ConstraintId,
            PointId = Owner.ShapeId,
            TargetShapeId = target.ShapeId,
            TargetType = type,
            T = t,
            U = u,
            V = v,
            Type = "RelativePoint"
        };

        public override void Cleanup()
        {
            if (target != null)
                target.OnChanged -= OnTargetChanged;
        }
    }

}