﻿using UnityEngine;

namespace Manipulator
{
    public static class MeshGenerator
    {
        public static Mesh CreateSphere(float radius)
        {
            GameObject temp = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            var mesh = GameObject.Instantiate(temp.GetComponent<MeshFilter>().sharedMesh);
            GameObject.Destroy(temp);
            return mesh;
        }

        public static Mesh CreateCylinder(float radius, float height)
        {
            GameObject temp = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            var mesh = GameObject.Instantiate(temp.GetComponent<MeshFilter>().sharedMesh);
            GameObject.Destroy(temp);
            return mesh;
        }

        public static Mesh CreateTorus(float radius, float thickness)
        {
            // TODO: Viết thuật toán tạo torus thủ công nếu muốn
            return CreateCylinder(thickness, radius); // placeholder
        }
    }

}