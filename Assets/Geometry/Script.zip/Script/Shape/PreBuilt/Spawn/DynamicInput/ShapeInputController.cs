using System.Collections.Generic;
using UnityEngine;

namespace Manipulator
{
    public class ShapeInputController : MonoBehaviour
    {
        public DynamicInputPanel inputPanel;
        public static ShapeInputController Instance { get; private set; }

        private IShapeSpawner currentSpawner;

        private void Awake()
        {
            Instance = this;
        }

        public void SetSpawner(IShapeSpawner spawner)
        {
            if (currentSpawner == spawner || spawner == null) return;

            currentSpawner = spawner;
            inputPanel.Build(spawner.GetFieldDefinitions());
        }

        public void ResetSpawner()
        {
            currentSpawner = null;
            inputPanel.Clear();
        }

        public void OnSubmit()
        {
            if (currentSpawner == null) return;

            var rawInputs = inputPanel.CollectInput();
            var solved = ShapeSolver.TrySolve(currentSpawner.GetFieldDefinitions(), rawInputs);
            inputPanel.FillCalculatedFields(solved);

            if (solved.Count >= 3) // tùy mỗi hình
            {
                ShapeData shape = currentSpawner.ComputeShape(solved);
                
                Debug.LogError($"[Click] Submit {shape != null}");
                Debug.LogError($"[Click] Submit solved {solved}");
                ShapeFactory.CreateFromData(shape);
                ResetSpawner(); // đóng panel sau khi vẽ
            }
            else
            {
                Debug.LogWarning("Chưa đủ dữ kiện để dựng hình.");
            }
        }
    }
}
