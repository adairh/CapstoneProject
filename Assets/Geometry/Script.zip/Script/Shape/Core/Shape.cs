﻿using System;
using System.Collections.Generic;
using UnityEngine;
using Manipulator.Data;

namespace Manipulator
{
    /// <summary>
    /// Lớp gốc cho mọi hình học – điều khiển logic và đồng bộ transform từ ShapeData.
    /// Không xử lý Netcode, UI hay input tại đây.
    /// </summary>
    public class Shape : MonoBehaviour
    {
        public string ShapeId { get; private set; }

        [SerializeField] private string shapeType;
        public string ShapeType => shapeType;

        public ShapeData Data { get; private set; }

        // Các pivot logic (Point)
        protected readonly List<Point> pivotPoints = new();
        public IReadOnlyList<Point> PivotPoints => pivotPoints;

        // Setting (màu sắc, độ dày, v.v.)
        protected readonly List<ISetting> settings = new();
        public IReadOnlyList<ISetting> Settings => settings;

        public event Action<Shape> OnChanged;

        #region INIT

        /// <summary>
        /// Khởi tạo từ dữ liệu có sẵn (dùng khi undo/redo/network/spawn).
        /// </summary>
        public virtual void Initialize(ShapeData data)
        {
            ShapeId = data.Id;
            shapeType = data.Type;
            Data = data;

            ApplyDataToTransform(data);
            ShapeStorage.Register(this);
        }

        /// <summary>
        /// Tạo mới hoàn toàn (khi vẽ lần đầu).
        /// </summary>
        public virtual void InitializeNew(string type, Vector3 position)
        {
            ShapeId = Guid.NewGuid().ToString();
            shapeType = type;
            Data = new ShapeData
            {
                Id = ShapeId,
                Type = type,
                Position = position,
                Rotation = Quaternion.identity,
                Scale = Vector3.one,
                ConnectedPointIds = new List<string>(),
                Settings = new Dictionary<string, string>()
            };

            ApplyDataToTransform(Data);
            ShapeStorage.Register(this);
        }

        #endregion

        #region TRANSFORM SYNC

        protected virtual void ApplyDataToTransform(ShapeData data)
        {
            transform.position = data.Position;
            transform.rotation = data.Rotation;
            transform.localScale = data.Scale;
        }

        protected virtual void UpdateDataFromTransform()
        {
            Data.Position = transform.position;
            Data.Rotation = transform.rotation;
            Data.Scale = transform.localScale;
        }

        #endregion

        #region PIVOT

        public void AddPivot(Point p)
        {
            if (!pivotPoints.Contains(p))
            {
                pivotPoints.Add(p);
                p.OnChanged += OnPivotChanged;
            }
        }

        public void RemovePivot(Point p)
        {
            if (pivotPoints.Remove(p))
                p.OnChanged -= OnPivotChanged;
        }

        protected virtual void OnPivotChanged(Point pt)
        {
            NotifyChanged();
        }

        public void MoveToPosition(Vector3 newPos, bool silent = false)
        {
            Vector3 delta = newPos - transform.position;
            transform.position = newPos;

            foreach (var p in pivotPoints)
                p.MoveTo(p.Position + delta);

            NotifyChanged(silent);
        }

        #endregion

        #region SETTINGS

        public void UpdateSetting(ISetting setting)
        {
            for (int i = 0; i < settings.Count; i++)
            {
                if (settings[i].GetType() == setting.GetType())
                {
                    settings[i] = setting;
                    ApplySetting(setting);
                    NotifyChanged();
                    return;
                }
            }

            settings.Add(setting);
            ApplySetting(setting);
            NotifyChanged();
        }

        protected virtual void ApplySetting(ISetting setting) { }

        public void AppendSettings(params ISetting[] newSettings)
        {
            settings.AddRange(newSettings);
            NotifyChanged();
        }

        #endregion

        #region SERIALIZE

        public virtual ShapeData Serialize()
        {
            UpdateDataFromTransform();
            return Data;
        }

        public virtual void Deserialize(ShapeData data)
        {
            Data = data;
            ApplyDataToTransform(data);
        }

        #endregion

        #region MISC

        public virtual void NotifyChanged(bool silent = false)
        {
            if (!silent)
                OnChanged?.Invoke(this);
        }

        public virtual void DestroyShape()
        {
            ShapeStorage.Unregister(this);
            Destroy(gameObject);
        }

        #endregion
    }
}
