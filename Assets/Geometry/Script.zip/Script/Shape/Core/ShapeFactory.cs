﻿using System;
using UnityEngine;
using Manipulator.Data;

namespace Manipulator
{
    /// <summary>
    /// Tạo mới Shape từ mã hoặc từ dữ liệu có sẵn.
    /// </summary>
    public static class ShapeFactory
    {
        public static Shape CreateShape(string type, Vector3 position)
        {
            Shape shape = null;
            switch (type)
            {
                case "Point":
                    shape = CreatePoint(position);
                    break;
                case "Segment":
                    shape = CreateSegment(position);
                    break; 
                default:
                    Debug.LogError($"Unknown shape type: {type}");
                    break;
            }

            return shape;
        }

        public static Shape CreateFromData(ShapeData data)
        {
            Shape shape = CreateShape(data.Type, data.Position);
            if (shape == null)
            {
                Debug.LogWarning($"Failed to create shape from data: {data.Type}");
                return null;
            }
            shape.Deserialize(data);
            return shape;
        }


        private static Shape CreatePoint(Vector3 position)
        {
            var go = new GameObject("Point");
            var shape = go.AddComponent<Point>();
            shape.InitializeNew("Point", position);

            // Mesh
            var mf = go.AddComponent<MeshFilter>();
            var mr = go.AddComponent<MeshRenderer>();
            mf.mesh = MeshGenerator.CreateSphere(0.1f); // tạo bằng code
            mr.material = MaterialLibrary.Get(MaterialType.Default);

            var collider = go.AddComponent<SphereCollider>();
            collider.radius = 0.1f;

            return shape;
        }

        private static Shape CreateSegment(Vector3 position)
        {
            var go = new GameObject("Segment");
            var shape = go.AddComponent<Segment>();
            shape.InitializeNew("Segment", position);

            var mf = go.AddComponent<MeshFilter>();
            var mr = go.AddComponent<MeshRenderer>();
            mf.mesh = MeshGenerator.CreateCylinder(0.05f, 1f);
            mr.material = MaterialLibrary.Get(MaterialType.Default);

            var collider = go.AddComponent<CapsuleCollider>();
            collider.radius = 0.05f;
            collider.height = 1f;
            collider.direction = 2; // Z axis

            return shape;
        }
 
    }
}
