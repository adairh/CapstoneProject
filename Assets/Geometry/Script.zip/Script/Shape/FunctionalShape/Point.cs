﻿using UnityEngine;
using Manipulator.Data;
using Manipulator.ShapeSystem;

namespace Manipulator.Shapes
{
    [RequireComponent(typeof(SphereCollider))]
    public class Point : Shape
    {
        private const float Radius = 0.1f;

        private SphereCollider collider;
        private FixedPointConstraint constraint;

        #region INIT

        protected override void Awake()
        {
            base.Awake();

            name = $"Point_{ShapeId}";

            // Add mesh
            var mf = gameObject.AddComponent<MeshFilter>();
            var mr = gameObject.AddComponent<MeshRenderer>();
            mf.mesh = MeshGenerator.CreateSphere(Radius);
            mr.material = MaterialLibrary.Get(MaterialType.Default);

            // Collider
            collider = GetComponent<SphereCollider>();
            collider.radius = Radius;
            collider.center = Vector3.zero;

            // Constraint
            constraint = gameObject.AddComponent<FixedPointConstraint>();
            constraint.Owner = this;
            ConstraintManager.Instance.RegisterConstraint(constraint);

            // Settings (position)
            AppendSettings(new PositionSetting(transform.position, this));
        }

        #endregion

        #region MOVE

        /// <summary>
        /// Di chuyển point đến vị trí mới. Nếu silent = true, không gửi sự kiện NotifyChanged.
        /// </summary>
        public void MoveTo(Vector3 newPosition, bool silent = false)
        {
            transform.position = newPosition;
            UpdateDataFromTransform();

            constraint.ApplyConstraint(this);
            ConstraintManager.Instance.ApplyConstraints(this);

            if (!silent)
                NotifyChanged();
        }

        public Vector3 GetCurrentPosition() => transform.position;

        #endregion

        #region SERIALIZATION

        public override ShapeData Serialize()
        {
            var data = base.Serialize();
            data.Type = "Point"; // đảm bảo đúng type khi Save/Load
            return data;
        }

        public override void Deserialize(ShapeData data)
        {
            base.Deserialize(data);
            // Nếu có thêm dữ liệu riêng sau này thì xử lý ở đây
        }

        #endregion

        #region ATTACH

        /// <summary>
        /// Gắn Point này làm pivot vào shape đang được chọn.
        /// </summary>
        public void AttachProcess()
        {
            var mm = ManipulationManager.Instance;
            var shape = mm.GetPinnedShape();

            if (shape != null && shape != this && !(shape is Point))
            {
                constraint.AddDepend(this, shape);
            }
        }

        public FixedPointConstraint GetPointConstraint() => constraint;

        #endregion

        #region OVERRIDES

        public override void CompleteDraw()
        {
            base.CompleteDraw();
            UpdateHitbox();
        }

        public override void UpdateHitbox()
        {
            if (collider == null)
                collider = GetComponent<SphereCollider>();
            collider.center = Vector3.zero;
        }

        #endregion
    }
}
