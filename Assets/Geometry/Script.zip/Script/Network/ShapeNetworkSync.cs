using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Geometry.Script.Network;
using Manipulator;
using UnityEngine;
using Unity.Netcode;

// Tạm đóng lại branch này vì Redo chưa work
public class ShapeNetworkSync : NetworkBehaviour
{
    private ManipulationManager mm = ManipulationManager.Instance;
    public enum ShapeType
    {
        None, Circle, Rectangle, Triangle, Segment, Point
    }

    
    public NetworkVariable<ShapeType> shapeType = new NetworkVariable<ShapeType>(ShapeType.None);
    public NetworkVariable<Vector3> startPoint = new NetworkVariable<Vector3>(Vector3.zero);
    public NetworkVariable<Vector3> currentPoint = new NetworkVariable<Vector3>(Vector3.zero);
    public NetworkVariable<bool> isDrawing = new NetworkVariable<bool>(false);
    public NetworkVariable<bool> isFinalized = new NetworkVariable<bool>(false);
    public NetworkVariable<ulong> ownerClientId = new NetworkVariable<ulong>(ulong.MaxValue); // Tracks who created the shape

    private Shape currentShape;

    
    public void LinkShape(Shape shape)
    {
        currentShape = shape;
        currentShape.AssignSyncer(this);
    }

    private string LogPrefix => $"[{(ownerClientId.Value == 0 ? "Host" : "Client")}:{ownerClientId.Value}]";
    
    // ==============================================================================================
    // Chỉnh cái khúc này cho nó theo logic của phép move bình thường
    
    [ServerRpc(RequireOwnership = false)]
    public void RequestMoveServerRpc(Vector3 newPosition)
    {
        ApplyPositionChange(newPosition);

        // Gửi cho các client còn lại
        ApplyMoveClientRpc(newPosition);
    }

    [ClientRpc]
    private void ApplyMoveClientRpc(Vector3 newPosition)
    {
        if (!IsOwner) // Tránh áp dụng lại với người đã gọi
            ApplyPositionChange(newPosition);
    }
    
    [ClientRpc]
    public void MovePivotsClientRpc(string pointName, Vector3 loc)
    {
        if (!IsOwner)
        {
            //Debug.LogError($"SNS: {pointName}");
            if (ShapeStorage.GetShapeByID(pointName) is Point point && currentShape != null)
            {
                currentShape.MovePivots(pointName, loc);
            }
        }
    }
 
    // 1) Client gọi lên server để request snap
    [ServerRpc(RequireOwnership = false)]
    public void RequestSnapPivotServerRpc(string role, string oldName, string newName)
    {
        // Server nhận request, broadcast xuống client
        SnapPivotClientRpc(role, oldName, newName);
    }

    public void RequestAllClientsShapeList()
    {
        AskClientsForShapeListClientRpc();
    }

    /// <summary>
    /// ClientRpc: server broadcast xuống, mỗi client nhận sẽ gửi từng shape của mình lên server.
    /// </summary>
    [ClientRpc]
    private void AskClientsForShapeListClientRpc()
    {
        // Nếu bạn muốn host cũng gửi, bỏ qua check này:
        if (!IsOwner) return;

        foreach (var shape in ShapeStorage.GetAllShapes())
        {
            ReportSingleShapeServerRpc(shape.Name, NetworkManager.LocalClientId);
        }
    }

    /// <summary>
    /// ServerRpc: mỗi client gọi lên server báo tên từng shape kèm clientId.
    /// </summary>
    [ServerRpc(RequireOwnership = false)]
    private void ReportSingleShapeServerRpc(string shapeName, ulong clientId)
    {
        //Debug.LogError($"[Server] Client {clientId} has shape: {shapeName}");
    }

    
    // 2) ClientRpc để mọi client (kể cả host) thực hiện snap đúng
    [ClientRpc]
    private void SnapPivotClientRpc(string role, string oldName, string newName)
    {

        if (IsOwner) return;
            // Chỉ xử lý nếu currentShape là Segment
        // if (!(currentShape is Segment seg)) return;

        // --- 2.1 Xóa pivot cũ nếu có ---

        foreach (Shape s in ShapeStorage.GetAllShapes())
        {
            //Debug.LogError($"meomeo meo {s.id} {s.Name}");
            //Debug.LogError($"meomeo {role} {oldName} {newName}");
        }
        
        if (ShapeStorage.GetShapeByID(oldName) is Point oldPt)
        {
            // Unsubscribe và destroy
            oldPt.OnChanged -= currentShape.OnChildChanged;
            oldPt.Destroy();
        }
        

        if (currentShape is Segment seg)
        {
            // --- 2.2 Lấy hoặc tạo pivot mới ---
            Point newPt;
            var maybeShape = ShapeStorage.GetShapeByID(newName);
            if (maybeShape is Point existingPt)
            {
                newPt = existingPt;
            }
            else
            {
                // Pivot mới chưa có trên client, tạo ra ở vị trí gần đúng
                var pos = (role == "Start") ? seg.Start.Position : seg.End.Position;
                newPt = new Point(pos);
                newPt.Name = newName;
                ShapeStorage.AddShape(newName, newPt);
            }

            // --- 2.3 Gán lại vào segment và subscribe sự kiện ---
            if (role == "Start") seg.Start = newPt;
            else if (role == "End") seg.End = newPt;

            newPt.OnChanged += seg.OnChildChanged;
            newPt.AttachToShape(seg);
            seg.ApplyTransform(false);
        }
        
        // --- 2.4 Redraw & cập nhật collider ---
        currentShape.Draw();
        currentShape.UpdateHitbox();
        currentShape.CompleteDraw();
    }
     
 
    public void MovePivots(Point position)
    {
        MovePivotsClientRpc(position.Name, position.Position);
    }
    
    private void ApplyPositionChange(Vector3 newPosition)
    {
        if (currentShape != null)
        {
            currentShape.MoveToPosition(newPosition);
        }
    }


    public void MoveShape(Vector3 newPos)
    {
        if (IsServer)
        {
            ApplyMoveClientRpc(newPos);
        }
        else
        {
            //RequestMoveServerRpc(newPos); // Client gọi Server để xử lý
        }
    }
    
    
    
    

    // ==============================================================================================
    
    private bool _hasFinalizedRun = false;

    public override void OnNetworkSpawn()
    {
        // 1) Subscribe các event
        shapeType.OnValueChanged    += OnShapeChanged;
        startPoint.OnValueChanged   += OnShapeChanged;
        currentPoint.OnValueChanged += OnShapeChanged;
        isDrawing.OnValueChanged    += OnDrawingChanged;
        isFinalized.OnValueChanged  += OnFinalizedChanged;

        // 2) Xử lý ngay lập tức tuỳ trạng thái currentValue
        if (isDrawing.Value)
        {
            // nếu wrapper đang ở giai đoạn preview
            _hasStarted = true;
            StartShape();
            // cho chắc, cập nhật một lần để preview phản ánh startPoint→currentPoint
            UpdateShape();
        }
        else if (isFinalized.Value)
        {
            // wrapper vừa được Spawn ở trạng thái finalized (thường là redo)
            _hasStarted   = true;
            _hasFinalized = true;
            StartShape();
            UpdateShape();
            FinalizeShape();
        }
    }

    public override void OnNetworkDespawn()
    {
        // reset flags để lần sau mà spawn lại ko dính state cũ
        _hasStarted   = false;
        _hasFinalized = false;
        // unsubscribe
        shapeType.OnValueChanged    -= OnShapeChanged;
        startPoint.OnValueChanged   -= OnShapeChanged;
        currentPoint.OnValueChanged -= OnShapeChanged;
        isDrawing.OnValueChanged    -= OnDrawingChanged;
        isFinalized.OnValueChanged  -= OnFinalizedChanged;
    }

    private void OnDrawingChanged(bool oldValue, bool newValue)
    {
        if (newValue && !_hasStarted)
        {
            _hasStarted = true;
            StartShape();
        }
    } 

    private bool _hasStarted = false;
    private bool _hasFinalized = false;

    private void OnShapeChanged<T>(T oldValue, T newValue)
    {
        // chỉ update khi đang vẽ
        if (isDrawing.Value && _hasStarted)
            UpdateShape();
    }

    private void OnFinalizedChanged(bool oldValue, bool newValue)
    {
        if (newValue && !_hasFinalized)
        {
            _hasFinalized = true;
            if (!_hasStarted)
            {
                _hasStarted = true;
                StartShape();
            }
            UpdateShape();
            FinalizeShape();
        }
    }

    private void TryHandleFinalize()
    {
        if (_hasFinalizedRun) return;   // chỉ chạy 1 lần
        _hasFinalizedRun = true;

        // 1) Tạo đối tượng Shape (giống StartShape)
        StartShape();
        // 2) Cập nhật preview đến điểm cuối
        UpdateShape();
        // 3) Chốt hẳn, tạo ra Point/Segment thật
        FinalizeShape();
    }


    private void StartShape()
    {
        currentShape = new Segment(startPoint.Value);
        currentShape.AssignSyncer(this);

        // ⬇️ Parent thẳng dưới cái GameObject của NetworkBehaviour
        currentShape.GO.transform.SetParent(this.transform, worldPositionStays: false);

        if (currentShape is ISynchronizedShape iSync)
            iSync.BeginSketch(startPoint.Value);
    }

    private void UpdateShape()
    {
        //Segment.UpdateSketch(currentPoint.Value);
        
        if (currentShape is ISynchronizedShape)
        {
            ISynchronizedShape iSync = (ISynchronizedShape)currentShape;
            iSync.UpdateSketch(currentPoint.Value);
        }
    }
    private void FinalizeShape()
    {
        //Segment.EndSketch(currentPoint.Value);
        
        if (currentShape is ISynchronizedShape)
        {
            ISynchronizedShape iSync = (ISynchronizedShape)currentShape;
            iSync.EndSketch(currentPoint.Value);
        }
    } 

    /*private void StartShape()
    {
        if (currentShape != null && currentShape.GO != null)
            Destroy(currentShape.GO);

        switch (shapeType.Value)
        {
            case ShapeType.Circle:
                currentShape = new Circle(startPoint.Value, 0);
                Debug.Log($"{LogPrefix} [ShapeNetworkSync] Created Circle at {startPoint.Value}");
                break;
            case ShapeType.Rectangle:
                currentShape = new Rectangle(startPoint.Value, 0, 0);
                Debug.Log($"{LogPrefix} [ShapeNetworkSync] Created Rectangle at {startPoint.Value}");
                break;
            case ShapeType.Triangle:
                currentShape = new Triangle(startPoint.Value, startPoint.Value, startPoint.Value);
                Debug.Log($"{LogPrefix} [ShapeNetworkSync] Created Triangle at {startPoint.Value}");
                break;
            case ShapeType.Segment:
                //currentShape = new Segment(new Point(startPoint.Value), new Point(startPoint.Value));
                //Debug.Log($"{LogPrefix} [ShapeNetworkSync] Created Segment at {startPoint.Value}");
                Segment.BeginSketch(startPoint.Value);
                break;
        }

        /*if (currentShape != null && currentShape.GO != null)
        {
            currentShape.GO.transform.SetParent(transform, false);
            currentShape.GO.SetActive(true);
            Debug.Log($"{LogPrefix} [ShapeNetworkSync] Shape GO: {currentShape.GO.name} at {currentShape.GO.transform.position}");
        }
        else
        {
            Debug.LogError($"{LogPrefix} [ShapeNetworkSync] Shape or GO is null after creation!");
        }#1#
        
        //mm.SetDrawing(true);
    }

    private void UpdateShape()
    {
        if (currentShape == null || !isDrawing.Value)
        {
            Debug.LogWarning($"{LogPrefix} [ShapeNetworkSync] UpdateShape skipped: Shape null or not drawing");
            return;
        }

        Debug.Log($"{LogPrefix} [ShapeNetworkSync] Updating {shapeType.Value} - Start: {startPoint.Value}, Current: {currentPoint.Value}");
        switch (shapeType.Value)
        {
            case ShapeType.Circle:
                ((Circle)currentShape).Radius = Vector3.Distance(startPoint.Value, currentPoint.Value);
                currentShape.Draw();
                break;
            case ShapeType.Rectangle:
                Vector3 size = currentPoint.Value - startPoint.Value;
                ((Rectangle)currentShape).Width = Mathf.Abs(size.x);
                ((Rectangle)currentShape).Height = Mathf.Abs(size.z);
                ((Rectangle)currentShape).Position = startPoint.Value + new Vector3(size.x / 2, 0, size.z / 2);
                currentShape.Draw();
                break;
            case ShapeType.Triangle:
                Vector3 thirdPoint = startPoint.Value + Vector3.Cross(currentPoint.Value - startPoint.Value, Vector3.up).normalized * Vector3.Distance(startPoint.Value, currentPoint.Value) * 0.5f;
                ((Triangle)currentShape).Corners[0].Position = startPoint.Value;
                ((Triangle)currentShape).Corners[1].Position = currentPoint.Value;
                ((Triangle)currentShape).Corners[2].Position = thirdPoint;
                currentShape.Draw();
                break;
            case ShapeType.Segment:
                //((Segment)currentShape).End.Position = currentPoint.Value;
                //currentShape.Draw();
                break;
        }

        if (currentShape.GO != null)
            Debug.Log($"{LogPrefix} [ShapeNetworkSync] Shape position: {currentShape.GO.transform.position}");
    }

    private void FinalizeShape()
    {
        if (currentShape != null)
        {
            currentShape.CompleteDraw();
            Debug.Log($"{LogPrefix} [ShapeNetworkSync] Finalized {shapeType.Value}");
            currentShape = null;
            mm.SetDrawing(false);
            
            
            switch (shapeType.Value)
            { 
                case ShapeType.Segment:
//                    ((Segment)currentShape).End.AttachToShape(currentShape);
//                    ((Segment)currentShape).Start.AttachToShape(currentShape);
                    break;
            }
            
            
        }
    }*/
    
}