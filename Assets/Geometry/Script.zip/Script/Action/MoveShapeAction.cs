﻿using Manipulator;
using UnityEngine;

namespace Geometry.Script.Action
{
    public class MoveShapeAction : IUndoableAction
    {
        private readonly string shapeId;
        private readonly Vector3 from;
        private readonly Vector3 to;

        public MoveShapeAction(string shapeId, Vector3 from, Vector3 to)
        {
            this.shapeId = shapeId;
            this.from = from;
            this.to = to;
        }

        public void Undo()
        {
            var shape = ShapeStorage.GetById(shapeId);
            if (shape is Point pt)
                pt.MoveTo(from, silent: true);
        }

        public void Redo()
        {
            var shape = ShapeStorage.GetById(shapeId);
            if (shape is Point pt)
                pt.MoveTo(to, silent: true);
        }
    }

}