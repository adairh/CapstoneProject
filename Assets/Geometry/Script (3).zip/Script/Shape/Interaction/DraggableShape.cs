﻿using UnityEngine;

namespace Manipulator
{
    public class DraggableShape : ShapeBehaviourBase
    {
        private Vector3 dragStartPosition;
        private bool isDragging;
        private Vector3 lastMousePosition;

        /// <summary>
        /// Called by ManipulationManager when dragging begins.
        /// </summary>
        public void BeginDrag()
        {
            if (shape == null || ManipulationManager.Instance.IsDrawing)
                return;

            isDragging = true;
            dragStartPosition = shape.transform.position;
            lastMousePosition = Input.mousePosition;
        }

        /// <summary>
        /// Called every frame while dragging.
        /// </summary>
        public void UpdateDrag()
        {
            if (!isDragging || shape == null || ManipulationManager.Instance.IsDrawing)
                return;

            Vector3 mouseDelta = Input.mousePosition - lastMousePosition;
            lastMousePosition = Input.mousePosition;

            float camDistance = Camera.main.WorldToScreenPoint(shape.transform.position).z;
            Vector3 worldPointNow = Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, camDistance));
            Vector3 worldPointPrev = Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x - mouseDelta.x, Input.mousePosition.y - mouseDelta.y, camDistance));
            Vector3 worldDelta = worldPointNow - worldPointPrev;

            Vector3 currentPos = shape.transform.position;
            Vector3 target = currentPos + worldDelta;

            // Axis locking
            if (Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl))
            {
                target.y = currentPos.y; // Lock Y
            }
            else if (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift))
            {
                target.x = currentPos.x;
                target.z = currentPos.z; // Lock XZ
            }

            shape.MoveTo(target, queue: false);
        }

        /// <summary>
        /// Called by ManipulationManager when dragging ends.
        /// </summary>
        public void EndDrag()
        {
            if (!isDragging || shape == null || ManipulationManager.Instance.IsDrawing)
                return;

            isDragging = false;
            Vector3 dragEndPosition = shape.transform.position;

            if (dragEndPosition != dragStartPosition)
            {
                UndoRedoNetworkBridge.Instance.DoAndBroadcast(
                    new MoveShapeAction(shape.ShapeId, dragStartPosition, dragEndPosition)
                );
            }
        }
    }
}
