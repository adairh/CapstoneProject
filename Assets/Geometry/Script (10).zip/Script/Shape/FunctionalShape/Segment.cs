﻿// Refactored Segment.cs — includes drawing logic in Segment.Drawer

using UnityEngine;
using Unity.Netcode;
using System;
using System.Collections.Generic;

namespace Manipulator
{
    public class Segment : Shape
    {
        public Point StartPoint { get; private set; }
        public Point EndPoint { get; private set; }

        private GameObject visual;

        private NetworkVariable<Vector3> previewEndPosition = new(
            writePerm: NetworkVariableWritePermission.Server
        );

        private bool isPreview = false;

        protected override void Awake()
        {
            base.Awake();
            visual = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            visual.transform.SetParent(transform);
            visual.GetComponent<Renderer>().material = MaterialLibrary.Get(MaterialType.Default);
            DestroyImmediate(visual.GetComponent<Collider>());
        }

        private void Update()
        {
            if (!isPreview || StartPoint == null) return;

            if (NetworkManager.Singleton.IsHost) return;

            SetEndPreviewPosition(previewEndPosition.Value);
        }

        public void MarkAsPreview() => isPreview = true;
        public void SetStartPoint(Point a) => StartPoint = a;

        public void SetEndPreviewPosition(Vector3 end)
        {
            if (StartPoint == null || visual == null) return;

            if (NetworkManager.Singleton.IsHost)
                previewEndPosition.Value = end;

            Vector3 start = StartPoint.transform.position;
            Vector3 mid = (start + end) / 2;
            Vector3 dir = end - start;

            float length = dir.magnitude;

            visual.transform.position = mid;
            visual.transform.rotation = Quaternion.LookRotation(dir);
            visual.transform.Rotate(90, 0, 0);
            visual.transform.localScale = new Vector3(0.05f, length / 2f, 0.05f);
        }

        public void SetEndpoints(Point a, Point b)
        {
            isPreview = false;
            StartPoint = a;
            EndPoint = b;
            AddPivot(a);
            AddPivot(b);
            UpdateVisual();
        }

        private void UpdateVisual()
        {
            if (StartPoint == null || EndPoint == null || visual == null) return;

            Vector3 a = StartPoint.transform.position;
            Vector3 b = EndPoint.transform.position;
            Vector3 mid = (a + b) / 2;
            Vector3 dir = b - a;
            float length = dir.magnitude;

            visual.transform.position = mid;
            visual.transform.rotation = Quaternion.LookRotation(dir);
            visual.transform.Rotate(90, 0, 0);
            visual.transform.localScale = new Vector3(0.05f, length / 2f, 0.05f);
        }

        protected override void OnPivotChanged(Point pt)
        {
            base.OnPivotChanged(pt);
            UpdateVisual();
        }

        public void ReconnectFromIds()
        {
            var a = ShapeStorage.GetById(Data.ConnectedPoints[0]) as Point;
            var b = ShapeStorage.GetById(Data.ConnectedPoints[1]) as Point;
            if (a != null && b != null) SetEndpoints(a, b);
        }

        public override ShapeData Serialize()
        {
            var data = base.Serialize();
            data.Type = "Segment";
            data.ConnectedPoints = new List<string>
            {
                StartPoint.ShapeId,
                EndPoint.ShapeId
            };
            return data;
        }

        public override void Deserialize(ShapeData data)
        {
            base.Deserialize(data);
            ReconnectFromIds();
        }

        // Inner drawing controller
        public static class Drawer
        {
            private static Point startPoint;
            private static Point ender;
            private static Segment preview;
            private static string pendingPointId;

            private enum State { None, Dragging }
            private static State current = State.None;

            public static void UpdateSegmentInput()
            {
                if (Input.GetMouseButtonDown(0)) Start();
                else if (Input.GetMouseButton(0)) Update();
                else if (Input.GetMouseButtonUp(0)) End();
            }

            private static void Start()
            {
                if (!PerformDrawing.RaycastMouse(out Vector3 pos)) return;

                var mm = ManipulationManager.Instance;
                if (mm.IsDrawing) return;
                mm.IsDrawing = true;

                pendingPointId = Guid.NewGuid().ToString();

                var pointData1 = new ShapeData
                {
                    Id = pendingPointId,
                    Type = "Point",
                    Position = pos,
                    Rotation = Quaternion.identity,
                    Scale = Vector3.one,
                    ConnectedPoints = new(),
                    Settings = new()
                };

                NetworkShapeSpawner.Instance.CreateShapeNetworked(pointData1);

                var pointData2 = new ShapeData
                {
                    Id = Guid.NewGuid().ToString(),
                    Type = "Point",
                    Position = pos,
                    Rotation = Quaternion.identity,
                    Scale = Vector3.one,
                    ConnectedPoints = new(),
                    Settings = new()
                };

                NetworkShapeSpawner.Instance.CreateShapeNetworked(pointData2);
                ender = ShapeStorage.GetById(pointData2.Id) as Point;


                string segId = Guid.NewGuid().ToString();
                var segData = new ShapeData
                {
                    Id = segId,
                    Type = "Segment",
                    Position = pos,
                    Rotation = Quaternion.identity,
                    Scale = Vector3.one,
                    ConnectedPoints = new() { pointData1.Id, pointData2.Id },
                    Settings = new()
                };

                NetworkShapeSpawner.Instance.CreateShapeNetworked(segData);

                preview = ShapeStorage.GetById(segId) as Segment;
                
                current = State.Dragging;
            }

            private static void Update()
            {
                if (current != State.Dragging || startPoint == null || ender == null) return;
                if (!PerformDrawing.RaycastMouse(out Vector3 pos)) return;

                var mm = ManipulationManager.Instance;
                if (!mm.IsDrawing) return;

                ender.MoveTo(pos);
            }

            private static void End()
            {
                if (current != State.Dragging || startPoint == null) return;
                if (!PerformDrawing.RaycastMouse(out Vector3 pos)) return;

                var mm = ManipulationManager.Instance;
                mm.IsDrawing = false;

                startPoint = null;
                ender = null;
                preview = null;
                pendingPointId = null;
                current = State.None;

                PerformDrawing.ResetMode();
            }

            public static void OnStartPointReady(Point p)
            {
                if (p.ShapeId == pendingPointId)
                    startPoint = p;
            }
        }
    }
}