﻿// UndoManager.cs

using System;
using System.Collections.Generic;
using UnityEngine;
using Unity.Netcode;

namespace Manipulator
{
    public class UndoRedoManager : MonoBehaviour
    {
        public static UndoRedoManager Instance { get; private set; }

        private readonly Stack<IUndoableAction> undoStack = new();
        private readonly Stack<IUndoableAction> redoStack = new();

        void Awake()
        {
            if (Instance != null) Destroy(gameObject);
            Instance = this;
        }

        public void Do(IUndoableAction action)
        {
            action.Redo();
            undoStack.Push(action);
            redoStack.Clear();
        }

        public void Undo()
        {
            if (undoStack.Count > 0)
            {
                var action = undoStack.Pop();
                action.Undo();
                redoStack.Push(action);
            }
        }

        public void Redo()
        {
            if (redoStack.Count > 0)
            {
                var action = redoStack.Pop();
                action.Redo();
                undoStack.Push(action);
            }
        }
    }

    public class CreateShapeAction : IUndoableAction
    {
        private readonly Shape shape;

        public CreateShapeAction(Shape shape)
        {
            this.shape = shape;
        }

        public void Undo()
        {
            shape.gameObject.SetActive(false);
        }

        public void Redo()
        {
            shape.gameObject.SetActive(true);
        }
    }

    public class MovePointAction : IUndoableAction
    {
        private readonly Point point;
        private readonly Vector3 from;
        private readonly Vector3 to;

        public MovePointAction(Point point, Vector3 from, Vector3 to)
        {
            this.point = point;
            this.from = from;
            this.to = to;
        }

        public void Undo() => point.MoveTo(from, true);
        public void Redo() => point.MoveTo(to, true);
    }
}
