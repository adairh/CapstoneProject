﻿using System;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using System.Collections.Generic;

[Serializable]
public class AIShapeResult
{
    public string ShapeType;
    public Dictionary<string, float> KnownFields;
    public string Explanation;
    public string[] Warnings;
    public string[] Suggestions;
}

public static class ChatGPTClient
{
    private static readonly string apiUrl = "https://api.openai.com/v1/chat/completions";

    private static string apiKey;

    static ChatGPTClient()
    {
        try
        {
            string path = Path.Combine(Directory.GetParent(Application.dataPath).FullName, ".openai");
            string[] lines = File.ReadAllLines(path);
            foreach (var line in lines)
            {
                if (line.StartsWith("OPENAI_KEY="))
                {
                    apiKey = line.Substring("OPENAI_KEY=".Length).Trim();
                    break;
                }
            }
        }
        catch (Exception e)
        {
            Debug.LogError($"[ChatGPTClient] Không đọc được API key từ file .openai: {e.Message}");
        }
    }

    public static async Task<string> Ask(string prompt)
    {
        if (string.IsNullOrEmpty(apiKey))
        {
            Debug.LogError("[ChatGPTClient] API key chưa được cấu hình.");
            return null;
        }

        using var client = new HttpClient();

        var body = new
        {
            model = "gpt-4",
            messages = new[]
            {
                new { role = "system", content = "Bạn là trợ lý dạy học hình học không gian. Phân tích đề bài và trả kết quả JSON." },
                new { role = "user", content = prompt }
            }
        };

        string jsonBody = JsonUtility.ToJson(new Wrapper(body));
        var content = new StringContent(jsonBody, Encoding.UTF8, "application/json");
        client.DefaultRequestHeaders.Clear();
        client.DefaultRequestHeaders.Add("Authorization", $"Bearer {apiKey}");

        try
        {
            HttpResponseMessage response = await client.PostAsync(apiUrl, content);
            string result = await response.Content.ReadAsStringAsync();
            return result;
        }
        catch (Exception e)
        {
            Debug.LogError($"[ChatGPTClient] Gửi request thất bại: {e.Message}");
            return null;
        }
    }

    [Serializable]
    private class Wrapper
    {
        public object model;
        public object[] messages;

        public Wrapper(dynamic input)
        {
            model = input.model;
            messages = input.messages;
        }
    }
}
