﻿using UnityEngine; 

namespace Manipulator
{
    public class PerformDrawing : MonoBehaviour
    {
        [SerializeField] private Camera cam;

        private Point currentStartPoint;
        private Segment currentPreviewSegment;

        void Update()
        {
            if (Input.GetMouseButtonDown(0))
                TryStartDrawing();

            if (currentPreviewSegment != null)
                UpdatePreviewSegment();

            if (Input.GetMouseButtonUp(0))
                FinishDrawing();
        }

        void TryStartDrawing()
        {
            if (!RaycastMouse(out Vector3 pos)) return;

            if (!RaycastPoint(out Point existing))
                existing = ShapeFactory.CreateShape("Point", pos) as Point;

            currentStartPoint = existing;

            var seg = ShapeFactory.CreateShape("Segment", pos) as Segment;
            seg.SetEndpoints(existing, existing); // preview

            currentPreviewSegment = seg;

            UndoRedoManager.Instance.Do(new CreateShapeAction(existing));
            UndoRedoManager.Instance.Do(new CreateShapeAction(seg));
        }

        void UpdatePreviewSegment()
        {
            if (!RaycastMouse(out Vector3 pos)) return;
            currentPreviewSegment.EndPoint.MoveTo(pos);
        }

        void FinishDrawing()
        {
            if (currentStartPoint == null || currentPreviewSegment == null)
                return;

            Point end;
            if (!RaycastPoint(out end))
            {
                if (!RaycastMouse(out Vector3 pos)) return;
                end = ShapeFactory.CreateShape("Point", pos) as Point;
                UndoRedoManager.Instance.Do(new CreateShapeAction(end));
            }

            currentPreviewSegment.SetEndpoints(currentStartPoint, end);

            currentStartPoint = null;
            currentPreviewSegment = null;
        }

        bool RaycastMouse(out Vector3 pos)
        {
            Ray ray = cam.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(ray, out RaycastHit hit))
            {
                pos = hit.point;
                return true;
            }

            pos = Vector3.zero;
            return false;
        }

        bool RaycastPoint(out Point point)
        {
            Ray ray = cam.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(ray, out RaycastHit hit))
            {
                point = hit.collider.GetComponent<Point>();
                return point != null;
            }

            point = null;
            return false;
        }
    }
}