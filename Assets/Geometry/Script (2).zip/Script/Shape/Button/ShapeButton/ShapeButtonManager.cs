﻿using System;
using UnityEngine;

namespace Manipulator
{
    public static class ShapeButtonManager
    {
        private static IShapeButton.ShapeType activeType = IShapeButton.ShapeType.None;

        public static IShapeButton.ShapeType ActiveType
        {
            get => activeType;
            private set
            {
                if (activeType != value)
                {
                    activeType = value;
                    Debug.Log($"[ShapeButtonManager] Active Shape Set To: {activeType}");
                    OnShapeChanged?.Invoke(activeType); // Notify listeners
                }
            }
        }

        public static event Action<IShapeButton.ShapeType> OnShapeChanged;

        public static void SetActiveShape(IShapeButton.ShapeType newType)
        {
            ActiveType = newType;
        }
    }
}