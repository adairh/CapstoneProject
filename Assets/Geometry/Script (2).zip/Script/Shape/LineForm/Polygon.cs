﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;

namespace Manipulator
{
    public class Polygon : Shape
    {
        private MeshCollider meshCollider;
        private MeshFilter meshFilter;
        private MeshRenderer meshRenderer;

        private GameObject visual;
        public List<Point> Points { get; } = new();

        protected override void Awake()
        {
            base.Awake();

            visual = new GameObject("PolygonMesh");
            visual.transform.SetParent(transform, false);

            meshFilter = visual.AddComponent<MeshFilter>();
            meshRenderer = visual.AddComponent<MeshRenderer>();
            meshCollider = visual.AddComponent<MeshCollider>();

            meshRenderer.material = DefaultMat;
            meshCollider.convex = true;
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();
            foreach (var p in Points)
                if (p != null)
                    p.OnPositionChanged -= OnPivotMoved;
        }

        public void AddPoint(Point p)
        {
            if (!Points.Contains(p))
            {
                Points.Add(p);
                AddPivot(p);
                p.OnPositionChanged += OnPivotMoved;
            }
        }

        public void CompletePolygon()
        {
            if (Points.Count < 3) return;
            GenerateMesh();
        }

        private void GenerateMesh()
        {
            if (Points.Count < 3) return;

            var vertices = Points.Select(p => transform.InverseTransformPoint(p.transform.position)).ToArray();
            var triangles = Triangulate(vertices);

            var mesh = new Mesh
            {
                name = "PolygonMesh",
                vertices = vertices,
                triangles = triangles
            };
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();

            meshFilter.sharedMesh = mesh;
            if (Points.Count >= 4)
            {
                try
                {
                    if (Points.Count >= 4)
                    {
                        meshCollider.sharedMesh = mesh;

                        // Apply colored transparent material
                        meshRenderer.material = new Material(DefaultMat);
                        meshRenderer.material.color = new Color(0.4f, 0.8f, 1f, 0.3f); // light blue transparent
                        meshRenderer.material.SetInt("_Cull", (int)CullMode.Off);
                        meshRenderer.material.SetFloat("_Mode", 3);
                        meshRenderer.material.SetInt("_SrcBlend", (int)BlendMode.SrcAlpha);
                        meshRenderer.material.SetInt("_DstBlend", (int)BlendMode.OneMinusSrcAlpha);
                        meshRenderer.material.SetInt("_ZWrite", 0);
                        meshRenderer.material.EnableKeyword("_ALPHABLEND_ON");
                        meshRenderer.material.renderQueue = 3000;

                        meshCollider.convex = true;
                    }
                    else
                    {
                        meshCollider.sharedMesh = mesh;

                        // Apply colored transparent material
                        meshRenderer.material = new Material(DefaultMat);
                        meshRenderer.material.color = new Color(0.4f, 0.8f, 1f, 0.3f); // light blue transparent
                        meshRenderer.material.SetInt("_Cull", (int)CullMode.Off);
                        meshRenderer.material.SetFloat("_Mode", 3);
                        meshRenderer.material.SetInt("_SrcBlend", (int)BlendMode.SrcAlpha);
                        meshRenderer.material.SetInt("_DstBlend", (int)BlendMode.OneMinusSrcAlpha);
                        meshRenderer.material.SetInt("_ZWrite", 0);
                        meshRenderer.material.EnableKeyword("_ALPHABLEND_ON");
                        meshRenderer.material.renderQueue = 3000;

                        meshCollider.convex = false;
                    }
                }
                catch
                {
                    Debug.LogWarning("[Polygon] MeshCollider failed. Using non-convex fallback.");
                    meshCollider.sharedMesh = mesh;

                    // Apply colored transparent material
                    meshRenderer.material = new Material(DefaultMat);
                    meshRenderer.material.color = new Color(0.4f, 0.8f, 1f, 0.3f); // light blue transparent
                    meshRenderer.material.SetInt("_Cull", (int)CullMode.Off);
                    meshRenderer.material.SetFloat("_Mode", 3);
                    meshRenderer.material.SetInt("_SrcBlend", (int)BlendMode.SrcAlpha);
                    meshRenderer.material.SetInt("_DstBlend", (int)BlendMode.OneMinusSrcAlpha);
                    meshRenderer.material.SetInt("_ZWrite", 0);
                    meshRenderer.material.EnableKeyword("_ALPHABLEND_ON");
                    meshRenderer.material.renderQueue = 3000;

                    meshCollider.convex = false;
                }

                meshCollider.convex = true;
            }
            else
            {
                meshCollider.sharedMesh = null;
            }
        }

        private int[] Triangulate(Vector3[] vertices)
        {
            List<int> indices = new();
            for (var i = 1; i < vertices.Length - 1; i++)
            {
                indices.Add(0);
                indices.Add(i);
                indices.Add(i + 1);
            }

            return indices.ToArray();
        }

        private void OnPivotMoved(Point pt)
        {
            GenerateMesh();
        }

        public override ShapeData Serialize()
        {
            var data = base.Serialize();
            data.Type = "Polygon";
            data.ConnectedPoints = Points.Select(p => p.ShapeId).ToList();
            return data;
        }

        public override void Deserialize(ShapeData data)
        {
            base.Deserialize(data);
            Points.Clear();

            foreach (var id in data.ConnectedPoints)
            {
                var shape = ShapeStorage.GetById(id);
                if (shape is Point p)
                    AddPoint(p);
            }

            CompletePolygon();
        }

        public override IEnumerable<Shape> GetDependentShapesForDelete()
        {
            yield return this;
            foreach (var p in Points)
                if (p != null && p.IsOnlyConnectedTo(this))
                    yield return p;
        }

        public static class Drawer
        {
            private const float SnapDistance = 0.2f;
            private static readonly List<Point> points = new();
            private static Segment previewSegment;
            private static Point previewPoint;
            private static string pendingPointId;
            private static string pendingPolygonId;
            private static CreateShapeBatchAction batch;

            public static void UpdatePolygonInput()
            {
                if (Input.GetMouseButtonDown(0)) Click();
                else UpdatePreview();
            }

            private static void Click()
            {
                if (!PerformDrawing.RaycastMouse(out var pos)) return;

                var snap = FindNearbyPoint(pos);
                var closing = snap != null && points.Count >= 3 && snap == points[0];
                if (closing)
                {
                    CompletePolygon();
                    return;
                }

                // Tạo point thật
                var newPointId = Guid.NewGuid().ToString();
                var pointData = new ShapeData
                {
                    Id = newPointId,
                    Type = "Point",
                    Position = pos,
                    Rotation = Quaternion.identity,
                    Scale = Vector3.one,
                    ConnectedPoints = new List<string>(),
                    Settings = new Dictionary<string, string>()
                };

                pendingPointId = newPointId;
                var pointBatch = new CreateShapeBatchAction(new List<ShapeData> { pointData });

                pointBatch.OnShapeSpawned = shape =>
                {
                    if (shape is Point pt && pt.ShapeId == pendingPointId)
                    {
                        // Spawn segment thật từ điểm trước tới điểm mới
                        if (points.Count > 0)
                        {
                            var segId = Guid.NewGuid().ToString();
                            var segData = new ShapeData
                            {
                                Id = segId,
                                Type = "Segment",
                                Position = Vector3.zero,
                                Rotation = Quaternion.identity,
                                Scale = Vector3.one,
                                ConnectedPoints = new List<string> { points.Last().ShapeId, pt.ShapeId },
                                Settings = new Dictionary<string, string>()
                            };

                            var segBatch = new CreateShapeBatchAction(new List<ShapeData> { segData });
                            UndoRedoNetworkBridge.Instance.DoAndBroadcast(segBatch);
                        }

                        points.Add(pt);

                        // Cập nhật hoặc tạo preview segment/point mới
                        if (previewPoint == null)
                        {
                            previewPoint = ShapeFactory.CreateShape("Point", pos) as Point;
                            ShapeStorage.Unregister(previewPoint);
                            previewPoint.SetRaycastIgnore(true);
                        }

                        if (previewSegment == null)
                        {
                            previewSegment = ShapeFactory.CreateShape("Segment", pos) as Segment;
                            previewSegment.MarkAsPreview();
                            previewSegment.SetRaycastIgnore(true);
                        }

                        previewSegment.SetStartPoint(pt);
                        previewSegment.SetEndPoint(previewPoint);
                    }
                };

                UndoRedoNetworkBridge.Instance.DoAndBroadcast(pointBatch);
            }

            private static void UpdatePreview()
            {
                if (previewPoint == null || previewSegment == null || points.Count == 0) return;
                if (!PerformDrawing.RaycastMouse(out var pos)) return;

                previewPoint.MoveTo(pos, queue: false);
                previewSegment.SetEndPoint(previewPoint);
            }

            private static void CompletePolygon()
            {
                if (points.Count < 3) return;

                // Tạo đoạn cuối cùng nối từ điểm cuối → điểm đầu
                var lastSegId = Guid.NewGuid().ToString();
                var finalSegData = new ShapeData
                {
                    Id = lastSegId,
                    Type = "Segment",
                    Position = Vector3.zero,
                    Rotation = Quaternion.identity,
                    Scale = Vector3.one,
                    ConnectedPoints = new List<string> { points.Last().ShapeId, points[0].ShapeId },
                    Settings = new Dictionary<string, string>()
                };

                var segBatch = new CreateShapeBatchAction(new List<ShapeData> { finalSegData });
                UndoRedoNetworkBridge.Instance.DoAndBroadcast(segBatch);

                // Tạo polygon
                pendingPolygonId = Guid.NewGuid().ToString();
                var polyData = new ShapeData
                {
                    Id = pendingPolygonId,
                    Type = "Polygon",
                    Position = Vector3.zero,
                    Rotation = Quaternion.identity,
                    Scale = Vector3.one,
                    ConnectedPoints = points.Select(p => p.ShapeId).ToList(),
                    Settings = new Dictionary<string, string>()
                };

                var polyAction = new CreateShapeBatchAction(new List<ShapeData> { polyData });
                UndoRedoNetworkBridge.Instance.DoAndBroadcast(polyAction);

                // Trước khi cleanup: giữ lại previewPoint như 1 point thật
                if (previewPoint != null)
                {
                    previewPoint.SetRaycastIgnore(false);
                    ShapeStorage.Register(previewPoint);
                    points.Add(previewPoint);
                }

                // Cleanup
                points.Clear();


                // Clean up previewPoint
                if (previewPoint != null)
                {
                    ShapeStorage.Unregister(previewPoint);
                    Destroy(previewPoint.gameObject);
                    previewPoint = null;
                }

                if (previewSegment != null)
                {
                    ShapeStorage.Unregister(previewSegment);
                    Destroy(previewSegment.gameObject);
                    previewSegment = null;
                }

                previewPoint?.DestroyShape();
                previewSegment?.DestroyShape();
                previewPoint = null;
                previewSegment = null;

                PerformDrawing.ResetMode();
            }

            private static Point FindNearbyPoint(Vector3 pos)
            {
                foreach (var shape in ShapeStorage.GetAllShapes())
                    if (shape is Point p && Vector3.Distance(p.transform.position, pos) < SnapDistance)
                        return p;
                return null;
            }
        }
    }
}