﻿// Refactored Segment.cs — fixed drag preview, proper reset, clean debug, and corrected syntax

using UnityEngine;
using Unity.Netcode;
using System;
using System.Collections.Generic;

namespace Manipulator
{
    public class Segment : Shape
    {
        public Point StartPoint { get; private set; }
        public Point EndPoint { get; private set; }

        private GameObject visual;
        private bool isPreview = false;

        protected override void Awake()
        {
            base.Awake();
            visual = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            visual.transform.SetParent(transform);
            visual.GetComponent<Renderer>().material = MaterialLibrary.Get(MaterialType.Default);
            DestroyImmediate(visual.GetComponent<Collider>());
        }

        private void Update()
        {
            if (isPreview && StartPoint != null && visual != null)
            {
                Vector3 a = StartPoint.transform.position;
                Vector3 b = EndPoint != null ? EndPoint.transform.position : a;
                Vector3 mid = (a + b) / 2;
                Vector3 dir = b - a;
                float length = dir.magnitude;

                visual.transform.position = mid;
                visual.transform.rotation = Quaternion.LookRotation(dir);
                visual.transform.Rotate(90, 0, 0);
                visual.transform.localScale = new Vector3(0.05f, length / 2f, 0.05f);

                Debug.Log($"[Segment.Update] isPreview={isPreview}, length={length}");
            }
        }

        public void MarkAsPreview()
        {
            isPreview = true;
            Debug.Log("[Segment] MarkAsPreview() called");
        }

        public void SetEndpoints(Point a, Point b)
        {
            StartPoint = a;
            EndPoint = b;
            AddPivot(a);
            AddPivot(b);
            UpdateVisual();
        }

        public void SetStartPoint(Point a)
        {
            StartPoint = a;
            AddPivot(a);
            Debug.Log($"[Segment] SetStartPoint({a.ShapeId})");
        }

        public void SetEndPoint(Point b)
        {
            EndPoint = b;
            AddPivot(b);
            UpdateVisual();
            Debug.Log($"[Segment] SetEndPoint({b.ShapeId})");
        }

        private void UpdateVisual()
        {
            if (StartPoint == null || EndPoint == null || visual == null) return;

            Vector3 a = StartPoint.transform.position;
            Vector3 b = EndPoint.transform.position;
            Vector3 mid = (a + b) / 2;
            Vector3 dir = b - a;
            float length = dir.magnitude;

            visual.transform.position = mid;
            visual.transform.rotation = Quaternion.LookRotation(dir);
            visual.transform.Rotate(90, 0, 0);
            visual.transform.localScale = new Vector3(0.05f, length / 2f, 0.05f);
        }

        protected override void OnPivotChanged(Point pt)
        {
            base.OnPivotChanged(pt);
            UpdateVisual();
        }

        public void ReconnectFromIds()
        {
            var a = ShapeStorage.GetById(Data.ConnectedPoints[0]) as Point;
            var b = ShapeStorage.GetById(Data.ConnectedPoints[1]) as Point;
            if (a != null && b != null) SetEndpoints(a, b);
        }

        public override ShapeData Serialize()
        {
            var data = base.Serialize();
            data.Type = "Segment";
            data.ConnectedPoints = new List<string>
            {
                StartPoint.ShapeId,
                EndPoint.ShapeId
            };
            return data;
        }

        public override void Deserialize(ShapeData data)
        {
            base.Deserialize(data);
            ReconnectFromIds();
        }

        public static class Drawer
        {
            private static Point startPoint;
            private static Point endPoint;
            private static Segment preview;
            private static string pendingStartId;
            private static string pendingEndId;
            private static string pendingSegId;

            private enum State { None, Dragging }
            private static State current = State.None;

            public static void UpdateSegmentInput()
            {
                if (Input.GetMouseButtonDown(0)) Start();
                else if (Input.GetMouseButton(0)) Update();
                else if (Input.GetMouseButtonUp(0)) End();
            }

            private static void Start()
            {
                if (!PerformDrawing.RaycastMouse(out Vector3 pos)) return;

                Debug.Log($"[Drawer] Start frame={Time.frameCount}, IsDrawing={ManipulationManager.Instance.IsDrawing}");

                var mm = ManipulationManager.Instance;
                if (mm.IsDrawing) return;
                mm.IsDrawing = true;

                pendingStartId = Guid.NewGuid().ToString();
                pendingEndId = Guid.NewGuid().ToString();
                pendingSegId = Guid.NewGuid().ToString();

                NetworkShapeSpawner.Instance.CreateShapeNetworked(new ShapeData
                {
                    Id = pendingStartId,
                    Type = "Point",
                    Position = pos,
                    Rotation = Quaternion.identity,
                    Scale = Vector3.one,
                    ConnectedPoints = new(),
                    Settings = new()
                });

                NetworkShapeSpawner.Instance.CreateShapeNetworked(new ShapeData
                {
                    Id = pendingEndId,
                    Type = "Point",
                    Position = pos,
                    Rotation = Quaternion.identity,
                    Scale = Vector3.one,
                    ConnectedPoints = new(),
                    Settings = new()
                });

                NetworkShapeSpawner.Instance.CreateShapeNetworked(new ShapeData
                {
                    Id = pendingSegId,
                    Type = "Segment",
                    Position = pos,
                    Rotation = Quaternion.identity,
                    Scale = Vector3.one,
                    ConnectedPoints = new() { pendingStartId, pendingEndId },
                    Settings = new()
                });

                current = State.Dragging;
            }

            private static void Update()
            {
                if (current != State.Dragging || startPoint == null || endPoint == null) return;
                if (!PerformDrawing.RaycastMouse(out Vector3 pos)) return;

                endPoint.MoveTo(pos);
                Debug.Log($"[Drawer] Update() dragging to {pos}");
            }

            private static void End()
            {
                if (current != State.Dragging || startPoint == null || endPoint == null || preview == null) return;

                Debug.Log("[Drawer] End drawing segment");
                ManipulationManager.Instance.IsDrawing = false;

                startPoint = null;
                endPoint = null;
                preview = null;

                pendingStartId = null;
                pendingEndId = null;
                pendingSegId = null;

                current = State.None;
                PerformDrawing.ResetMode();
            }

            public static void OnStartPointReady(Point p)
            {
                Debug.Log($"[Drawer] OnStartPointReady: {p.ShapeId}, pendingStart={pendingStartId}, pendingEnd={pendingEndId}");

                if (p.ShapeId == pendingStartId)
                    startPoint = p;
                else if (p.ShapeId == pendingEndId)
                    endPoint = p;

                if (startPoint != null && endPoint != null && preview == null)
                {
                    preview = ShapeStorage.GetById(pendingSegId) as Segment;
                    if (preview != null)
                    {
                        preview.SetStartPoint(startPoint);
                        preview.SetEndPoint(endPoint);
                        preview.MarkAsPreview();
                        Debug.Log("[Drawer] Preview segment initialized");
                    }
                }
            }
        }
    }
}
