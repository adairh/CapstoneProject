﻿// Refactored PerformDrawing.cs to support drawing mode via enum selector

using UnityEngine;
using System;
using System.Collections.Generic;
using Unity.Netcode;

namespace Manipulator
{
    public class PerformDrawing : MonoBehaviour
    {
        public static PerformDrawing Instance { get; private set; }

        public enum DrawingMode
        {
            None,
            Point,
            Segment
        }

        [Header("Drawing Mode")]
        public DrawingMode drawingMode = DrawingMode.None;

        private enum DragState { None, Dragging }
        private DragState currentState = DragState.None;

        private string pendingStartPointId;
        private Point currentStartPoint;
        private Segment previewSegment;

        private void Awake()
        {
            Debug.Log("PerformDrawing Awake on: " + gameObject.name);
            Instance = this;
        }


        private void Update()
        {
            if (!NetworkManager.Singleton.IsHost) return;

            switch (drawingMode)
            {
                case DrawingMode.Point:
                    Point.Drawer.UpdatePointInput();
                    break;
                case DrawingMode.Segment:
                    Segment.Drawer.UpdateSegmentInput();
                    break;
            }
        }

        void DrawSinglePoint()
        {
            if (!RaycastMouse(out Vector3 pos)) return;

            string pointId = Guid.NewGuid().ToString();
            var pointData = new ShapeData
            {
                Id = pointId,
                Type = "Point",
                Position = pos,
                Rotation = Quaternion.identity,
                Scale = Vector3.one,
                ConnectedPoints = new(),
                Settings = new()
            };

            NetworkShapeSpawner.Instance.CreateShapeNetworked(pointData);

            drawingMode = DrawingMode.None; // Reset mode after draw
        }

        

        public void OnStartPointReady(Point point)
        {
            if (point.ShapeId != pendingStartPointId) return;
            currentStartPoint = point;
        }

        public static bool RaycastMouse(out Vector3 pos)
        {
            pos = Vector3.zero;
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(ray, out RaycastHit hit))
            {
                pos = hit.point;
                return true;
            }
            return false;
        }

        public static void ResetMode()
        {
            if (Instance != null)
                Instance.drawingMode = DrawingMode.None;
        }
    }
}
